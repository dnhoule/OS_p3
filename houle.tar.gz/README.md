Name: Dylan Houle
Wisc: dnhoule

Completion:

    Almost working, some weird edge case bugs. Does not pass tests because of session issue. 

Resources:

    Used GNU C Library